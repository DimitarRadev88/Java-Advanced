package com.generics.lab.jar;

public class Pickle {

}
